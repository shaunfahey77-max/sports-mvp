// apps/api/src/routes/score.js
import express from "express";

/* =========================================================
   Score Router + Scoring Helpers

   - Default export: Express router mounted at /api/score
   - Named export: scoreCompletedGames(league, date, games)

   Premium rules:
   - Only "home" or "away" counts as a PICK
   - "PASS" (or null/anything else) counts as NO PICK
   - Grade only finals + only real picks
   ========================================================= */

const router = express.Router();

router.get("/ping", (_req, res) => {
  res.json({ ok: true, route: "score" });
});

function isFinalStatus(g) {
  const s = String(g?.status || "").toLowerCase();
  return s === "final" || s === "post" || s === "completed";
}

function getScoresFromGame(g) {
  const hs =
    typeof g?.homeScore === "number"
      ? g.homeScore
      : typeof g?.home?.score === "number"
      ? g.home.score
      : null;

  const as =
    typeof g?.awayScore === "number"
      ? g.awayScore
      : typeof g?.away?.score === "number"
      ? g.away.score
      : null;

  return { homeScore: hs, awayScore: as };
}

function winnerSide(homeScore, awayScore) {
  if (typeof homeScore !== "number" || typeof awayScore !== "number") return null;
  if (homeScore === awayScore) return "push";
  return homeScore > awayScore ? "home" : "away";
}

function normalizePick(raw) {
  const s = String(raw ?? "").trim().toLowerCase();
  if (s === "home" || s === "away") return s;
  return null; // treat PASS/empty/etc as no pick
}

export async function scoreCompletedGames(league, date, games = []) {
  const list = Array.isArray(games) ? games : [];

  let inputGames = list.length;
  let completed = 0;
  let picks = 0;
  let graded = 0;
  let wins = 0;
  let losses = 0;
  let pushes = 0;
  let noPick = 0;

  const details = [];

  for (const g of list) {
    const rawPick = g?.market?.pick ?? g?.pick?.pick ?? g?.pick ?? null;
    const pick = normalizePick(rawPick);

    if (!pick) noPick++;
    else picks++;

    if (!isFinalStatus(g)) continue;

    completed++;

    // grade only if we actually had a pick
    if (!pick) {
      details.push({
        game_key: g?.gameKey ?? g?.game_key ?? g?.gameId ?? g?.id ?? null,
        matchup:
          g?.matchup ||
          `${g?.away?.abbr || g?.away?.name || "AWAY"} @ ${g?.home?.abbr || g?.home?.name || "HOME"}`,
        status: g?.status ?? null,
        homeScore: g?.homeScore ?? g?.home?.score ?? null,
        awayScore: g?.awayScore ?? g?.away?.score ?? null,
        pick: "PASS",
        result: "PASS",
        market: g?.market?.marketType ?? "moneyline",
      });
      continue;
    }

    const { homeScore, awayScore } = getScoresFromGame(g);
    const winner = winnerSide(homeScore, awayScore);

    if (!winner) continue;

    graded++;

    if (winner === "push") {
      pushes++;
      details.push({
        game_key: g?.gameKey ?? g?.game_key ?? g?.gameId ?? g?.id ?? null,
        matchup:
          g?.matchup ||
          `${g?.away?.abbr || g?.away?.name || "AWAY"} @ ${g?.home?.abbr || g?.home?.name || "HOME"}`,
        status: g?.status ?? null,
        homeScore,
        awayScore,
        pick,
        result: "PUSH",
        market: g?.market?.marketType ?? "moneyline",
      });
      continue;
    }

    if (pick === winner) wins++;
    else losses++;

    details.push({
      game_key: g?.gameKey ?? g?.game_key ?? g?.gameId ?? g?.id ?? null,
      matchup:
        g?.matchup ||
        `${g?.away?.abbr || g?.away?.name || "AWAY"} @ ${g?.home?.abbr || g?.home?.name || "HOME"}`,
      status: g?.status ?? null,
      homeScore,
      awayScore,
      pick,
      result: pick === winner ? "WIN" : "LOSS",
      market: g?.market?.marketType ?? "moneyline",
    });
  }

  const winRate = graded ? wins / graded : null;

  return {
    ok: true,
    league: String(league || "").toLowerCase(),
    date: String(date || "").slice(0, 10),
    counts: {
      inputGames,
      completed,
      picks,
      graded,
      wins,
      losses,
      pushes,
      noPick,
    },
    metrics: {
      winRate,
      avgEdge: null,
      avgWinProb: null,
      avgConfidence: null,
    },
    details,
  };
}

router.post("/run", async (req, res) => {
  try {
    const league = String(req.body?.league || "").toLowerCase();
    const date = String(req.body?.date || "").slice(0, 10);
    const games = Array.isArray(req.body?.games) ? req.body.games : [];

    const report = await scoreCompletedGames(league, date, games);
    res.json({ ok: true, report });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e?.message || e) });
  }
});

export default router;