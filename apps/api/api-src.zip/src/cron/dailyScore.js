// apps/api/src/cron/dailyScore.js
import cron from "node-cron";
import { upsertPerformanceDaily, writeSlatePicksToLedger } from "../db/dailyLedger.js";

/**
 * Single runner used by BOTH:
 * - the scheduled cron
 * - the manual /api/admin/run-cron endpoint
 *
 * Supports multi-league scoring:
 *   /api/admin/run-cron?date=YYYY-MM-DD&leagues=nba,nhl,ncaam&force=1&grade=all
 */
export async function runDailyScoreOnce({ date, leagues, modelVersion, lookbackDays } = {}) {
  // Default = yesterday (UTC-safe date math)
  const d = new Date();
  d.setUTCDate(d.getUTCDate() - 1);
  const ymd = (date && String(date).trim()) || d.toISOString().slice(0, 10);

  const leagueList = Array.isArray(leagues)
    ? leagues.map((s) => String(s).trim().toLowerCase()).filter(Boolean)
    : String(leagues || "nba,nhl,ncaam")
        .split(",")
        .map((s) => s.trim().toLowerCase())
        .filter(Boolean);

  // Defaults
  const mv = String(modelVersion || "v2").trim() || "v2";

  const defaultLookbackByLeague = {
    nba: 14,
    nhl: 40,
    ncaam: 45,
  };

  const parsedLb = Number(lookbackDays);
  const hasLb = Number.isFinite(parsedLb) && parsedLb > 0;

  console.log(`[CRON] Running scoring job for ${ymd} (leagues=${leagueList.join(",") || "nba"})`);

  // Lazy imports prevent circular dependency issues
  const { buildNbaPredictions, buildNhlPredictions, buildNcaamPredictions } = await import("../routes/predict.js");
  const { scoreCompletedGames } = await import("../routes/score.js");

  const results = [];
  let totalGames = 0;

  for (const league of leagueList) {
    const lb = hasLb ? parsedLb : (defaultLookbackByLeague[league] ?? 14);

    try {
      if (league === "nba") {
        const nba = await buildNbaPredictions(ymd, lb, { modelVersion: mv });

        await writeSlatePicksToLedger({
          date: ymd,
          league: "nba",
          games: nba?.games || [],
          modelVersion: mv,
        });

        const report = await scoreCompletedGames("nba", ymd, nba?.games || []);

        const counts = report?.counts || {};
        const metrics = report?.metrics || {};

        await upsertPerformanceDaily({
          date: ymd,
          league: "nba",
          games: counts.inputGames ?? (Array.isArray(nba?.games) ? nba.games.length : 0),
          completed: counts.completed ?? 0,
          picks: counts.picks ?? 0,
          wins: counts.wins ?? 0,
          losses: counts.losses ?? 0,
          pushes: counts.pushes ?? 0,
          pass: counts.noPick ?? 0,

          win_rate: metrics.winRate ?? null,

          model_version: mv,
          vegas_ok: nba?.meta?.vegasOk ?? null,

          error: report?.ok === false ? "score_failed" : null,
          notes: null,
        });

        const slateGames = Array.isArray(nba?.games) ? nba.games.length : 0;
        totalGames += slateGames;

        results.push({ league: "nba", ok: true, date: ymd, scoredGames: slateGames, report });
        continue;
      }

      if (league === "nhl") {
        const nhl = await buildNhlPredictions(ymd, lb, { modelVersion: mv });

        await writeSlatePicksToLedger({
          date: ymd,
          league: "nhl",
          games: nhl?.games || [],
          modelVersion: mv,
        });

        const report = await scoreCompletedGames("nhl", ymd, nhl?.games || []);

        const counts = report?.counts || {};
        const metrics = report?.metrics || {};

        await upsertPerformanceDaily({
          date: ymd,
          league: "nhl",
          games: counts.inputGames ?? (Array.isArray(nhl?.games) ? nhl.games.length : 0),
          completed: counts.completed ?? 0,
          picks: counts.picks ?? 0,
          wins: counts.wins ?? 0,
          losses: counts.losses ?? 0,
          pushes: counts.pushes ?? 0,
          pass: counts.noPick ?? 0,

          win_rate: metrics.winRate ?? null,

          model_version: mv,
          vegas_ok: nhl?.meta?.vegasOk ?? null,

          error: report?.ok === false ? "score_failed" : null,
          notes: null,
        });

        const slateGames = Array.isArray(nhl?.games) ? nhl.games.length : 0;
        totalGames += slateGames;

        results.push({ league: "nhl", ok: true, date: ymd, scoredGames: slateGames, report });
        continue;
      }

      if (league === "ncaam") {
        const ncaam = await buildNcaamPredictions(ymd, lb, { modelVersion: mv });

        await writeSlatePicksToLedger({
          date: ymd,
          league: "ncaam",
          games: ncaam?.games || [],
          modelVersion: mv,
        });

        const report = await scoreCompletedGames("ncaam", ymd, ncaam?.games || []);

        const counts = report?.counts || {};
        const metrics = report?.metrics || {};

        await upsertPerformanceDaily({
          date: ymd,
          league: "ncaam",
          games: counts.inputGames ?? (Array.isArray(ncaam?.games) ? ncaam.games.length : 0),
          completed: counts.completed ?? 0,
          picks: counts.picks ?? 0,
          wins: counts.wins ?? 0,
          losses: counts.losses ?? 0,
          pushes: counts.pushes ?? 0,
          pass: counts.noPick ?? 0,

          win_rate: metrics.winRate ?? null,

          model_version: mv,
          vegas_ok: ncaam?.meta?.vegasOk ?? null,

          error: report?.ok === false ? "score_failed" : null,
          notes: null,
        });

        const slateGames = Array.isArray(ncaam?.games) ? ncaam.games.length : 0;
        totalGames += slateGames;

        results.push({ league: "ncaam", ok: true, date: ymd, scoredGames: slateGames, report });
        continue;
      }

      results.push({ league, ok: false, date: ymd, scoredGames: 0, report: null, error: `unsupported_league:${league}` });
    } catch (err) {
      console.error(`[CRON] Error scoring ${league} for ${ymd}:`, err);
      results.push({
        league,
        ok: false,
        date: ymd,
        scoredGames: 0,
        report: null,
        error: String(err?.message || err),
      });
    }
  }

  console.log(`[CRON] Completed scoring for ${ymd} (totalGames=${totalGames})`);

  return {
    ok: true,
    ranFor: ymd,
    scoredGames: totalGames,
    results,
  };
}

/**
 * Schedule daily run at 03:30 AM Eastern Time
 */
export function startDailyScoreJob() {
  const expr = "30 3 * * *"; // 03:30 local (America/New_York)

  cron.schedule(
    expr,
    async () => {
      try {
        await runDailyScoreOnce(); // defaults to yesterday + nba/nhl/ncaam
      } catch (err) {
        console.error("[CRON] Unhandled error:", err);
      }
    },
    { timezone: "America/New_York" }
  );

  console.log(`[CRON] Scheduled daily scoring job: "${expr}" (America/New_York — 03:30 AM Eastern)`);
}

/**
 * Compatibility export for /api/admin/run-cron
 */
export async function runDailyScoreForDate(date, opts = {}) {
  return runDailyScoreOnce({ date, ...opts });
}